Carta Natal de Florencia
========================

1. Abrí index.html en tu navegador para probar.
2. Subí TODA esta carpeta a GitHub.
3. Activá GitHub Pages desde Settings > Pages.

Carpetas:
- images/: imágenes estáticas
- media/: gifs
- papers/: papers PDF
